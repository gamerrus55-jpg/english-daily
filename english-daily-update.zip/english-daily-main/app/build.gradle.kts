plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ru.my.englishdaily"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.my.englishdaily"
        minSdk = 26
        targetSdk = 34
        // Номер сборки растёт с каждой сборкой на GitHub, чтобы APK ставился поверх старого
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
        // Общий рейтинг: ключ подставляется при сборке на GitHub и даёт доступ только к репозиторию статистики
        buildConfigField("String", "STATS_TOKEN", "\"" + (System.getenv("STATS_TOKEN") ?: "") + "\"")
        buildConfigField("String", "STATS_REPO", "\"gamerrus55-jpg/english-daily-stats\"")
    }

    // Постоянный ключ подписи: обновления ставятся поверх, прогресс не теряется
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
}
